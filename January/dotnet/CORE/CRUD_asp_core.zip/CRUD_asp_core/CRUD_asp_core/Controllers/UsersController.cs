﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CRUD_asp_core.Models;
using CRUD_asp_core.Interfaces;

namespace CRUD_asp_core.Controllers
{
    public class UsersController : Controller
    {
        private readonly IUsersRepository _UsersRepository;

        public UsersController(IUsersRepository context)
        {
            this._UsersRepository = context;
        }

        public async Task<IActionResult> Index()
        {
            var users = _UsersRepository.GetAll();
            return View(users);
        }
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(User user)
        {
            if (ModelState.IsValid)
            {
                _UsersRepository.Create(user);
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = _UsersRepository.FindById(id.Value);
            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }


        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = _UsersRepository.FindById(id.Value);
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, User user)
        {
            if (id != user.UserId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _UsersRepository.Update(id, user);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_UsersRepository.IsExists(user.UserId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = _UsersRepository.FindById(id.Value);
            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            _UsersRepository.Delete(id);
            return RedirectToAction(nameof(Index));
        }

    }
}

﻿using System;
using System.Collections.Generic;

namespace CRUD_asp_core.Models;

public partial class Book
{
    public int BookId { get; set; }

    public string Title { get; set; } = null!;

    public int? AuthorId { get; set; }

    public int? CategoryId { get; set; }

    public int? PublicationYear { get; set; }

    public string? Isbn { get; set; }

    public int Quantity { get; set; }

    public int AvailableQuantity { get; set; }

    public virtual Author? Author { get; set; }

    public virtual ICollection<Borrowing> Borrowings { get; set; } = new List<Borrowing>();

    public virtual Category? Category { get; set; }
}

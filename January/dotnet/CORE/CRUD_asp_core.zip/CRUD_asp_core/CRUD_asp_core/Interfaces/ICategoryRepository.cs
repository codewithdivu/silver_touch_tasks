﻿using CRUD_asp_core.Models;

namespace CRUD_asp_core.Interfaces
{
    public interface ICategoryRepository
    {
        Category FindById(int categoryId);
        IEnumerable<Category> GetAll();
        void Create(Category category);
        void Update(int categoryId,Category category);
        void Delete(int categoryId);
        bool IsExists(int categoryId);
    }
}

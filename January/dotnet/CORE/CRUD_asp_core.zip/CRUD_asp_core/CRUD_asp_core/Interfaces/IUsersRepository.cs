﻿using CRUD_asp_core.Models;

namespace CRUD_asp_core.Interfaces
{
    public interface IUsersRepository
    {
        User FindById(int userID);
        IEnumerable<User> GetAll();
        void Create(User user);
        void Update(int userID, User updatedUser);
        void Delete(int userID);
        bool IsExists(int userID);
    }
}

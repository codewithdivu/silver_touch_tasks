﻿using CRUD_asp_core.Interfaces;
using CRUD_asp_core.Models;

namespace CRUD_asp_core.Repositories
{
    public class UsersRepository : IUsersRepository
    {
        LibraryDbContext _context;
        public UsersRepository(LibraryDbContext context) {
            _context = context;
        }

        public User FindById(int userID)
        {
            return _context.Users.FirstOrDefault(u => u.UserId == userID);

        }
        public IEnumerable<User> GetAll()
        {
            return _context.Users.ToList();
        }

        public void Create(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public void Update(int userID, User updatedUser)
        {
            var existingUser = _context.Users.Find(userID);
            if (existingUser != null)
            {
                existingUser.FirstName = updatedUser.FirstName;
                existingUser.LastName = updatedUser.LastName;   
                existingUser.Email = updatedUser.Email;
                _context.SaveChanges();
            }
        }

        public void Delete(int userID)
        {
            // first deleting all the borrowers related to this userid
            var borrowers = _context.Borrowings.Where(br => br.UserId == userID);

            foreach (var item in borrowers)
            {
                _context.Borrowings.Remove(item);
            }
            _context.SaveChanges();

            // deleting user
            var user = _context.Users.Find(userID);
            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
            }
        }
        public bool IsExists(int userID)
        {
            return _context.Users.Any(e => e.UserId == userID);
        }
    }
}

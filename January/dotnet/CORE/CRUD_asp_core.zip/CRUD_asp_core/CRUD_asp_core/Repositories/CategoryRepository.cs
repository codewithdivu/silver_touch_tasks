﻿using CRUD_asp_core.Interfaces;
using CRUD_asp_core.Models;
using System.Linq;


namespace CRUD_asp_core.Repositories
{
    public class CategoryRepository : ICategoryRepository
    {
        LibraryDbContext _context;
        public CategoryRepository(LibraryDbContext context)
        {
            _context = context;
        }

        public Category FindById(int categoryId)
        {
            return _context.Categories.FirstOrDefault(c => c.CategoryId == categoryId);
        }

        public IEnumerable<Category> GetAll()
        {
            return _context.Categories.ToList();
        }

        public void Create(Category category)
        {
            _context.Categories.Add(category);
            _context.SaveChanges();
        }

        public void Update(int categoryId, Category updatedCategory)
        {
            var existingCategory = _context.Categories.Find(categoryId);

            if (existingCategory != null)
            {
                existingCategory.CategoryName = updatedCategory.CategoryName;
                _context.SaveChanges();
            }
        }

        public void Delete(int categoryId)
        {
            //first deleting all the books related to this categoryid

            var books = _context.Books.Where(book => book.CategoryId == categoryId);
            foreach (var item in books)
            {
                _context.Books.Remove(item);
            }
            _context.SaveChanges();


            // deleting category
            var category = _context.Categories.Find(categoryId);
            if (category != null)
            {
                _context.Categories.Remove(category);
                _context.SaveChanges();
            }

        }
        public bool IsExists(int categoryId)
        {
            return _context.Categories.Any(e => e.CategoryId == categoryId);
        }

    }
}

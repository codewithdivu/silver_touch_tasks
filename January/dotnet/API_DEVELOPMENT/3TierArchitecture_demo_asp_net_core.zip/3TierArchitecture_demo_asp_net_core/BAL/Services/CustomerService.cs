﻿using DAL.Contracts;
using DAL.Models;

namespace BAL.Services
{
    public class CustomerService 
    {
        public readonly IRepository<Customer> _repository;
        public CustomerService(IRepository<Customer> repository)
        {
            _repository = repository;
        }
        public async Task<Customer> AddCustomer(Customer customer)
        {
            try
            {
                if (customer == null)
                {
                    throw new ArgumentNullException(nameof(customer));
                }
                else
                {
                    return await _repository.Create(customer);
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void DeleteCustomer(int Id)

        {
            try
            {
                if (Id != 0)
                {
                    var obj = _repository.GetAll().Where(x => x.CustomerId == Id).FirstOrDefault();
                    _repository.Delete(obj);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void UpdateCustomer(int Id)

        {
            try
            {
                if (Id != 0)
                {
                    var obj = _repository.GetAll().Where(x => x.CustomerId == Id).FirstOrDefault();
                    if (obj != null)
                        _repository.Update(obj);
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public IEnumerable<Customer> GetAllCustomers()
        {
            try
            {
                return _repository.GetAll().ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Customer GetCustomer(int id)
        {
            try
            {
                return _repository.GetById(id);
            }
            catch (Exception)
            {
                throw;
            }
        }


    }
}
